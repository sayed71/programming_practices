# 10. Programming Contest

## Programming Contest
If you are a first-year Computer Science student in a university, we highly recommend you to participate in a programming contest. 

## For Beginners
There are online programming contests as well. Just Google, "programming contest for beginners" and you will get a lot of them.

Also, there are many websites like HackerRank, LeetCode, etc. where you can practice problem-solving in your favorite programming language. 

## Looking for a job
However, if you are learning programming yourself or need to get a job quickly, you can skip programming contests. 

Just focus on learning and building a few software.

## Real-world problems
The real-world problems that we are covering in Programming Hero will be enough for you to move forward. 

## Keep going
Keep going. Keep learning. 
Happy Journey.

&nbsp;
[![Next Page](../assets/next-button.png)](../Simple-Game/Guess-game.md)
&nbsp;